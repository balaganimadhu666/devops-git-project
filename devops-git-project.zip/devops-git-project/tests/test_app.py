from app.app import app


def test_home():
    response = app.test_client().get("/")
    assert response.status_code == 200
    assert response.get_json()["version"] == "1.0.0"


def test_health():
    response = app.test_client().get("/health")
    assert response.status_code == 200
    assert response.get_json() == {"status": "ok"}
