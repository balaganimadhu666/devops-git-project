# Changelog

All notable changes to this project are documented here.
Format based on [Keep a Changelog](https://keepachangelog.com/) and [Semantic Versioning](https://semver.org/).

## [1.0.0] - 2026-10-28
### Added
- Flask app with `/` and `/health` endpoints
- Unit tests with pytest
- Dockerfile for containerizing the app
- GitHub Actions CI pipeline (test + Docker build)
- `.gitignore`, README and Git workflow documentation
- Answers to Git interview questions
